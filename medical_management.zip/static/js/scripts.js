// scripts.js

document.addEventListener('DOMContentLoaded', function () {
    const quantityInputs = document.querySelectorAll('.quantity');
    const priceInputs = document.querySelectorAll('.price');
    const totalInput = document.getElementById('totalAmount');

    function calculateTotal() {
        let total = 0;
        quantityInputs.forEach((quantityInput, index) => {
            const quantity = parseInt(quantityInput.value) || 0;
            const price = parseFloat(priceInputs[index].dataset.price) || 0;
            total += quantity * price;
        });
        totalInput.textContent = `Total: $${total.toFixed(2)}`;
    }

    quantityInputs.forEach(input => {
        input.addEventListener('input', calculateTotal);
    });
});
